# Privacy Policy for che-word-mcp

## Overview

che-word-mcp is a local MCP (Model Context Protocol) server that processes Microsoft Word documents (.docx) on your device. This privacy policy explains how the server handles your data.

## Data Collection

**che-word-mcp does NOT collect, transmit, or store any personal data.** All document processing happens entirely on your local machine.

## Data Processing

- **Local Processing Only**: All Word documents are processed locally on your device
- **No Network Transmission**: The server does not send any document content, metadata, or usage information to external servers
- **No Telemetry**: No usage analytics or telemetry data is collected
- **No Cloud Storage**: Documents are never uploaded to cloud services

## File Access

The server only accesses files that you explicitly specify through MCP tool calls:
- Documents you open with `open_document`
- Documents you create with `create_document`
- Paths you specify with `save_document`
- Images you insert with `insert_image`

## Third-Party Services

che-word-mcp does not integrate with any third-party services. It operates as a standalone local server.

## Data Retention

- Documents remain in their original locations on your filesystem
- The server does not create any persistent storage or cache files
- Open documents are held in memory only during your session
- Closing the MCP server releases all document data from memory

## Security

- The server runs locally with the same permissions as the parent process
- No network ports are opened by the server itself
- Communication occurs through stdio transport only

## Updates to This Policy

Any changes to this privacy policy will be reflected in this file within the mcpb package.

## Contact

For privacy-related questions or concerns, please open an issue at:
https://github.com/kiki830621/che-word-mcp

---

Last updated: 2026-01-18
